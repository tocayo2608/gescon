USE gescon;

INSERT INTO Rol (nombre) VALUES
                             ('autor'),
                             ('revisor'),
                             ('jefe_comite');
