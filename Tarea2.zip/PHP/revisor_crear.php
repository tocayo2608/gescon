<?php
require_once __DIR__ . '/middleware/auth_required.php';

$titulo    = 'Crear Revisor – GESCON';
$contenido = __DIR__ . '/revisor_crear_view.php';
include __DIR__ . '/layout.php';
