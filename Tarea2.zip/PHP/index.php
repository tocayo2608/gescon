<?php
header('Location: /gescon/PHP/router.php?page=dashboard');
exit;
